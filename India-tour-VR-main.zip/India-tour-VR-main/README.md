# India-tour-VR
A Virtual Reality tour of Indian sights and monuments featuring 360 photos 

#Installation

1.git clone the repository
2.Run the html file or create your local server (eg:-python -m http.server 3000 )
3.you can experience VR mode

#output![output3](https://user-images.githubusercontent.com/83947378/154301984-b2804d8d-4ec1-4c40-891a-b03a5ee2a684.jpg)
![output1](https://user-images.githubusercontent.com/83947378/154301998-72bbe55a-3902-4656-add0-bf15c0fba26b.jpg)
![output2](https://user-images.githubusercontent.com/83947378/154302002-e2c681ff-c1e5-411f-9a08-c166b19fef2d.jpg)
