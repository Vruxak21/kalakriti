export const SIGNUP_LOADING = "signup/loading";
export const SIGNUP_SUCCESS = "signup/success";
export const SIGNUP_ERR = "signup/error";
export const LOGIN_LOADING = "login/loading";
export const LOGIN_SUCCESS = "login/success";
export const LOGIN_ERR = "login/error";
export const LOGOUT = "logout";