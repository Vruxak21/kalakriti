# puzzle-phaser
HTML5 Jigsaw Puzzle with PhaserJS

A simple HTML5 jigsaw puzzle using PhaserJS library.
