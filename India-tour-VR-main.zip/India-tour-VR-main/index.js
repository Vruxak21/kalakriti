function show(id) {
  document.getElementById('sky').setAttribute('src', '#' + id);
}
